#!/bin/bash

#判断字符串以xxx结尾 hasSuffix xxx path
function hasSuffix() {
 echo "判断 $2是否包含$1"
 content=$1;
 path=$2
 case $path in
       *.txt) 
 echo "true" 
;;
        *)
 echo "false" 
;;
 esac
}

#处理单个需要处理的文件
function dealFile() {
  file=$1
  echo "正在处理单个文件$file"
  basePath=`pwd`
  file=${file#./}
  echo "去除./后的路径$file"
  filePath=${basePath}/${file}
  echo "全路径 $filePath"
  sed -i "" "s/456/456/g" $filePath
}

hasSuffix txt content.txt

echo  "是否包含：$?"


#找到包含指定内容的文件:findFile "content" path
function findAndDealFile() {
#查找内容
  list=$(grep -Rl "$1" $2)
echo "参数0是$0" 
 for element in ${list[@]}
 do
    if [ $element != $0 ] ; then
        echo "处理文件$element";
	 dealFile "$element";
    fi;
  done;
}

findAndDealFile $1 $2


